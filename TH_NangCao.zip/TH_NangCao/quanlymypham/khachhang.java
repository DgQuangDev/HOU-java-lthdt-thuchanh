package quanlymypham;
import java.util.Scanner;

public class khachhang {
    int idKH;
    String nameKH;
    String sodienthoai;
    String diachi;
    String danhsachmua;
    public khachhang(){
        
    }
    public khachhang(int idKH, String nameKH, String sodienthoai, String diachi) {
        this.idKH = idKH;
        this.nameKH = nameKH;
        this.sodienthoai = sodienthoai;
        this.diachi = diachi;
    }
    public int getidKH(){
        return idKH;
    }
    public void setidKH(int idKH){
        this.idKH = idKH;
    }
    public String getnameKH(){
        return nameKH;
    }
    public void setnameKH(String nameKH){
        this.nameKH = nameKH;
    }
    public String getsodienthoai(){
        return sodienthoai;
    }
    public void setsodienthoai(String sodienthoai){
        this.sodienthoai = sodienthoai;
    }
    public String getdiachi(){
        return diachi;
    }
    public void setdiachi(String diachi){
        this.diachi = diachi;
    }

    public void nhapKH(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhap ma khach hang:");
        idKH = sc.nextInt();
        System.out.println("Nhap ten khach hang:");
        nameKH = sc.nextLine();
        System.out.println("Nhap so dien thoai cua khach hang:");
        sodienthoai = sc.nextLine();
        System.out.println("Nhap dia chi cua khach hang:");
        diachi = sc.nextLine();

    }
    public void xuatKH(){
        System.out.println("Ma cua khach hang:"+getidKH());
        System.out.println("Ten cua khach hang:"+getnameKH());
        System.out.println("So dien thoai cua khach hang:"+getsodienthoai());
        System.out.println("Dia chi cua khach hang:"+getdiachi());
}
}