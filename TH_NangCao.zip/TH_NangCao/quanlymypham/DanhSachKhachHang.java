package quanlymypham;
import java.util.ArrayList;
import java.util.Scanner;


public class DanhSachKhachHang {
    ArrayList<khachhang> ds = new ArrayList<>();
    int n;
    Scanner sc = new Scanner(System.in);
    
    public void nhapDSKH(){
        System.out.println("Nhap so luong khach hang: ");
        n=sc.nextInt();
        for(int i=0;i<n;i++){
            khachhang x= new khachhang();
            System.out.println("Nhap kHach hang thu"+ (i+1));
            x.nhapKH();
            ds.add(x);
        }
    }
    
    public void hienDSKH(){
        System.out.println("Danh sach khach hang: ");
        System.out.printf("%-25s%-15s%-10s","ID","Ho ten","So Dien Thoai","Dia chi");
        for(int i=0;i<n;i++){
            System.out.println("");
            ds.get(i).xuatKH();
        }
        System.out.println("");
    }
}
