package quanlymypham;
import java.util.ArrayList;
import java.util.Scanner;


public class DanhSachMyPham {
    ArrayList<mypham> ds = new ArrayList<>();
    int n;
    Scanner sc = new Scanner(System.in);
    
    public void nhapDSMP(){
        System.out.println("Nhap so luong my pham: ");
        n=sc.nextInt();
        for(int i=0;i<n;i++){
            mypham x= new mypham();
            System.out.println("Nhap hoc sinh thu"+ (i+1));
            x.nhapMP();
            ds.add(x);
        }
    }
    
    public void hienDSMP(){
        System.out.println("Danh sach my pham: ");
        System.out.printf("%-25s%-15s%-10s","ID","Name","Soluong","Dongia","Loai");
        for(int i=0;i<n;i++){
            System.out.println("");
            ds.get(i).xuatMP();
        }
        System.out.println("");
    }
}