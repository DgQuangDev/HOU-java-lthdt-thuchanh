package quanlymypham;
import java.util.ArrayList;
import java.util.Scanner;

public class main {
    static void menu(){
        System.out.println("1. Nhap danh sach my pham");
        System.out.println("2. Xuat danh sach my pham");
        System.out.println("3. Nhap danh sach khach hang");
        System.out.println("4. Xuat danh sach khach hang");
        System.out.println("5. Nhap hoa don");
        System.out.println("6. Xuat hoa don");
        System.out.println("0. Thoat");
    }
    public static void main(String[] args) {
        int chon;
        Scanner sc = new Scanner(System.in);
        DanhSachKhachHang dskh= new DanhSachKhachHang();
        DanhSachMyPham dsmp = new DanhSachMyPham();
        do {            
            menu();
            System.out.println("Lua chon: ");
            chon= sc.nextInt();
            switch(chon){
                case 1: dsmp.nhapDSMP(); break;
                case 2: dsmp.hienDSMP(); break;
                case 3: dskh.nhapDSKH(); break;
                case 4: dskh.hienDSKH(); break;
                case 5: 
                case 6:
                case 0: System.exit(0); break;
                default: break;
            }
        } while (chon!=0);
    }
    
}
