package quanlymypham;
import java.util.Scanner;

public class mypham{
    int idMP;
    String nameMP;
    int soluongMP;
    float dongiaMP;
    String loaiMP;

public mypham(){
    
}

public mypham(int idMP, String nameMP, int soluongMP ,float dongiaMP ,String loaiMP){
    this.idMP=idMP;
    this.nameMP=nameMP;
    this.soluongMP=soluongMP;
    this.dongiaMP=dongiaMP;
    this.loaiMP=loaiMP;
}
public int getidMP(){
    return idMP;
}
public void setidMP(int idMP){
    this.idMP=idMP;
}

public String getnameMP(){
    return nameMP;
}
public void setnameMP(String nameMP){
    this.nameMP=nameMP;
}

public int getsoluongMP(){
    return soluongMP;
}
public void setsoluongMP(int soluongMP){
    this.soluongMP=soluongMP;
}

public float getdongiaMP(){
    return dongiaMP;
}
public void setdongiaMP(float dongiaMP){
    this.dongiaMP=dongiaMP;
}

public String getloaiMP(){
    return loaiMP;
}

public void setloaiMP(String loaiMP){
    this.loaiMP=loaiMP;
}
public void nhapMP(){
    Scanner sc=new Scanner(System.in);
    System.out.println("Nhap ma cua my pham:");
    this.idMP=sc.nextInt();
    System.out.println("Nhap ten cua my pham:");
    this.nameMP=sc.nextLine();
    System.out.println("Nhap so luong my pham:");
    this.soluongMP=sc.nextInt();
    System.out.println("Nhap don gia my pham:");
    this.dongiaMP=sc.nextFloat();
    System.out.println("Nhap loai my pham:");
    this.loaiMP=sc.nextLine();
}
public void xuatMP(){
    System.out.println("Ma cua my pham:"+getidMP());
    System.out.println("Ten cua my pham:"+getnameMP());
    System.out.println("So luong my pham:"+getsoluongMP());
    System.out.println("Don gia my pham:"+getdongiaMP());
    System.out.println("Loai my pham:"+getloaiMP());
}
}